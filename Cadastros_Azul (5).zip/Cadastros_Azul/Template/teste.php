Chamaremos de login.php
[php]
<?
//conecta com o db
include (“conectar.php”);
$nome= $_POST[‘nome’];
$senha = $_POST[‘senha’];
//faz a confirmação de nome e senha no db
$logar = mysql_query(SELECT * FROM login WHERE nome=’$nome’ AND senha=’$senha)') or die(“erro ao selecionar”);
/*aqui depois de verificado redirecionamos a pagina secreta(caso nome e senha estarem corretos) ou senha e apelido não conferem 
caso tais estiverem errados. Repare que há uma rotina para o valor inserido em senha não seja nulo.

obs: Aonde esta escrito paginasecreta.php é aonde vc deve colocar a página para onde o script ira redirecionar*/
'
if (strlen($senha)< 1)
echo 

Senha ou apelido não conferem
<a href=”javascript:history.back(1);”>tente denovo</a>;

elseif (mysql_num_rows($logar)>0 ){
header(“location:paginasecreta.php”);
} else {
echo 

Senha ou apelido não conferem
<a href=”javascript:history.back(1);”>tente denovo</a>;
}
?>