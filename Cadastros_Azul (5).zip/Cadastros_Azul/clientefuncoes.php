<?php
# Aluna: Giovana Franklin Pereira de Castro (4ºADS-Vespertino) RA- 0210481712018;
#-------------------------------------------------------------------------------------------------------------------
function picklist($acao,$salto)
{
  global $link;
  # O Pickilist é 'chamado' em três programas... portanto deve retornar o form para três diferentes programas
  # que são determinados na variável $prg, usando operadores ternários.
  $prg=($acao=="Consultar") ? "clienteconsultar.php" : ( ($acao=="Alterar") ? "clientealterar.php" : "clienteexcluir.php" );  
  # Lendo os dados de uma tabela por um comando de projeção
  $cmdsql="SELECT idcliente, nomefantasia FROM cliente ORDER BY nomefantasia";
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  printf("$cmdsql\n");
  # construindo o form recursivo que apresenta a picklist
  printf("<form action='./$prg' method='POST'>\n");
  printf("<input type='hidden' name='salto' value=$salto>\n");
  printf("<input type='hidden' name='acao'  value=$acao>\n");
  printf("<input type='hidden' name='bloco' value=2>\n");
  $execcmd=pg_query($link,$cmdsql);
  printf("<select name='idcliente'>\n");
  while ( $REG=pg_fetch_array($execcmd) )
  {
    printf("<option value='$REG[idcliente]'>$REG[nomefantasia]-($REG[idcliente])</option>\n");
  }
  printf("</select>\n");
  botoes(FALSE,TRUE,TRUE,TRUE,"$acao",$salto);
  printf("</form>\n");
}
function mostraregistro($CP)
{
  global $link;
 
  $cmdsql="SELECT * FROM cliente
		              WHERE cliente.idcliente='$CP'";
  # executando a variável.
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  # printf("$cmdsql\n");
  $execcmd=pg_query($link,$cmdsql);
  $REG=pg_fetch_array($execcmd);
  
  printf("<table border=1>\n");
  		printf("<tr><td>Código Cliente</td><td>$REG[idcliente]</td></tr>\n");
		printf("<tr><td>Nome Fantasia</td><td>$REG[nomefantasia]</td></tr>\n");
		printf("<tr><td>Raz&atilde;o Social</td><td>$REG[razaosocial]</td></tr>\n");
		printf("<tr><td>CNPJ</td><td>$REG[cnpj]</td></tr>\n");
		printf("<tr><td>Endereço</td><td>$REG[endereco]</td></tr>\n");
		printf("<tr><td>Estado</td><td>$REG[estado]</td></tr>\n");
        printf("<tr><td>Bairro</td><td>$REG[bairro]</td></tr>\n");
        printf("<tr><td>Cidade</td><td>$REG[cidade]</td></tr>\n");
		printf("<tr><td>CEP</td><td>$REG[cep]</td></tr>\n");
		printf("<tr><td>Email</td><td>$REG[email]</td></tr>\n");
		printf("<tr><td>Telefone</td><td>$REG[telefone]</td></tr>\n");
		printf("<tr><td>Inscrição Estadual</td><td>$REG[inscricaoestadual]</td></tr>\n");
		printf("<tr><td>Tipo Estabelecimento</td><td>$REG[tipoestabelecimento]</td></tr>\n");
		printf("<tr><td>Filial</td><td>$REG[filial]</td></tr>\n");
  
  printf("</table>\n");
}
function montaform($acao,$bloco,$salto)
{ 
  global $link;
  $PK=(isset($_POST['idcliente'])) ? $_POST['idcliente'] : " " ; 
  # Criar um vetor com valores dos campos do registro lido na tabela.
  //$co= pg_query();
  #$bd = pg_query($link,"SELECT * FROM cliente WHERE idcliente='$PK'");
  $reg=(isset($POST['idcliente'])) ? "" : pg_fetch_array(pg_query($link,"SELECT * FROM cliente WHERE idcliente='$PK'"));
  #$reg=pg_fetch_array(pg_query($link," SELECT * FROM cliente WHERE idcliente='$PK'"));
  #$reg=pg_fetch_array($bd);
 
  $bloco=$bloco+1;
  $mens=(isset($reg['idcliente'])) ? $reg['idcliente']."- N&Atilde;O Ser&aacute; Alterado pelo sistema" : "Ser&aacute; gerado pelo sistema";
  $prg=( $acao=='Incluir' ) ? "./clienteincluir.php" : "./clientealterar.php" ;
 
  printf("<form action='$prg'  method='POST'>\n");
  printf("<input type='hidden' name='acao'  value='$acao'>\n");
  printf("<input type='hidden' name='bloco' value='$bloco'>\n");
  printf("<input type='hidden' name='salto' value='$salto'>\n");
  printf("%s",(isset($reg['idcliente'])) ? "<input type='hidden' name='idcliente' value='".$reg['idcliente']."'>\n" : "");
  # Agora se monta uma tabela com os campos para entrada de dados.
  printf("<table border=0>\n");
  printf("<tr><td>C&oacute;digo:</td><td>$mens</td></tr>\n");
  printf("<tr><td>Razão Social:</td><td><input type='text' name='razaosocial' value=\"$reg[razaosocial]\" size=60 maxlength=250></td></tr>\n");
  printf("<tr><td>Nome Fantasia:</td><td><input type='text' name='nomefantasia' value=\"$reg[nomefantasia]\" size=20 maxlength=30></td></tr>\n");
  printf("<tr><td>CNPJ:</td><td><input type='text' name='cnpj' value=\"$reg[cnpj]\" size=20 maxlength=15></td></tr>\n");
  printf("<tr><td>Endereço:</td><td><input type='text' name='endereco' value=\"$reg[endereco]\" size=20 maxlength=15></td></tr>\n");
  
  #printf("</td></tr>\n");
  
  printf("<tr><td>Bairro:</td><td><input type='text' name='bairro' value=\"$reg[bairro]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Cidade:</td><td><input type='text' name='cidade' value=\"$reg[cidade]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Estado:</td><td><input type='text' name='estado' value=\"$reg[estado]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>CEP:</td><td><input type='text' name='cep' value=\"$reg[cep]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Email:</td><td><input type='text' name='email' value=\"$reg[email]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Telefone:</td><td><input type='text' name='telefone' value=\"$reg[telefone]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Inscrição Estadual:</td><td><input type='text' name='inscricaoestadual' value=\"$reg[inscricaoestadual]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Filial:</td><td><input type='text' name='filial' value=\"$reg[filial]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Tipo de Estabelecimento:</td><td><input type='text' name='tipoestabelecimento' value=\"$reg[tipoestabelecimento]\" size=20 maxlength=20></td></tr>\n");
  
  
  
  # montando os botões do form com a função botoes e os parâmetros:
  # (Página,Menu,Saída,Reset,Ação,$salto) TRUE | FALSE para os 4 parâmetros esq-dir.
  printf("<tr><td colspan=2>");
  botoes(FALSE,TRUE,TRUE,TRUE,$acao,$salto); # função do setfuncoes.php
  printf("</td></tr>\n");
  printf("</table>\n");
  printf("</form>\n");
}
?>