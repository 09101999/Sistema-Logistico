<?php

printf("<html>\n");
printf("<head>\n");
printf(" <meta charset='utf-8'>\n");
printf("<title>Transit-Transporte</title>\n");
printf("<link rel='icon' type='image/png' href='images/Package.ico'/>\n");
printf("</head>\n");
printf("</head>\n");
printf("<frameset rows='50,*' frameborder='no'>\n");
printf("  <frame name='Q1' src='menuTransporte.html' scrolling='no'>\n");
printf("  <frame name='Q2' src='transincluir.php'>\n");
printf("</frameset>\n");
printf("</html>\n");
?>