<?php

printf("<html>\n");
printf("<head>\n");
printf(" <meta charset='utf-8'>\n");
printf("<title>Transit-Cliente</title>\n");
printf("<link rel='icon' type='image/png' href='images/Package.ico'/>\n");
printf("</head>\n");
#printf("<body class='blurBg-false' style='background-image:url(mapas.jpg)' position= 'center center'>\n");
printf("<frameset rows='50,*' frameborder='no'>\n");
printf("  <frame name='Q1' src='menuCliente.html' scrolling='no'>\n");
printf("  <frame name='Q2' src='clienteincluir.php'>\n");
printf("</frameset>\n");
#printf("<body>\n");
printf("</html>\n");
?>