<?php

require_once("../setfuncoes.php");# Atribuindo o valor de $bloco e $salto.
# Carregar o arquivo com as funções locais da tabela editora
require_once("./clientefuncoes.php");

$acao = ( ISSET($_POST['acao'])  ) ? $_POST['acao'] : "Consultar";
$bloco= ( ISSET($_POST['bloco']) ) ? $_POST['bloco'] : '1';
$salto= ( ISSET($_POST['salto']  ) ? $_POST['salto']+1 : '1');   // $salto recebe $_POST['salto']+1 (se houver), senão 1
$corfundo=( $acao=='Listar' AND $bloco==3 ) ? "#FFFFFF" /* white */ : "#FFDEAD" /* navajowhite */ ;
$corfonte="#000000"; # black - Cor da Fonte que é usada nos textos das telas (exceto títulos)
# iniciando a página
iniciapagina("Cliente",$acao,$corfundo);
# Divisor principal de execução do programa
switch (TRUE)
{
  case ( $bloco==1 ):
  { # Montar a picklist
    picklist($acao,$salto);
    break;
  }
  case ( $bloco==2 ):
  { # Capturar valores digitados e montar tabela Campo|Valor
    mostraregistro("$_REQUEST[idcliente]");
    # montando os botões do form com a função botoes e os parâmetros:
    # (Página,Menu,Saída,Reset,Ação,$salto) TRUE | FALSE para os 4 parâmetros esq-dir.
    botoes(TRUE,TRUE,TRUE,FALSE,NULL,$salto); # função do setfuncoes.php
    break;
  }
}
fimdepagina($acao,"clienteconsultar.php",FALSE);
?>