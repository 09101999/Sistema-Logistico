<?php

require_once("../setfuncoes.php");# Atribuindo o valor de $bloco e $salto.
# Carregar o arquivo com as funções locais da tabela editora
require_once("./transfuncoes.php");

$acao = ( ISSET($_POST['acao'])  ) ? $_POST['acao'] : "Incluir";
$bloco= ( ISSET($_POST['bloco']) ) ? $_POST['bloco'] : '1';
$salto= ( ISSET($_POST['salto']  ) ? $_POST['salto']+1 : '1');   // $salto recebe $_POST['salto']+1 (se houver), senão 1
$corfundo=( $acao=='Listar' AND $bloco==3 ) ? "#FFFFFF" /* white */ : "#87CEEB" /* navajowhite */ ;
$corfonte="#000000"; # black - Cor da Fonte que é usada nos textos das telas (exceto títulos)
# iniciando a página
iniciapagina("Transporte",$acao,$corfundo);
# Divisor principal de execução do programa
switch (TRUE)
{ # 1
  case ( $bloco==1 ):
  { # 1.1-Montar o form para entrada dos dados de médicos.
    montaform($acao,$bloco,$salto);
    break;
  }
  case ( $bloco==2 ):
  { 
    if ( pg_num_rows(pg_query($link,"SELECT * FROM transporte WHERE idtransporte='$_REQUEST[idtransporte]'"))>0 )
    { # Mostra ao usuario uma mensagem e disponibiliza um botão voltar.
     # printf("Já existe no Banco dados uma combinação Nome Cor gravada com os valores: $_REQUEST[txnomecor]<br>\n");
      botoes(TRUE,FALSE,FALSE,FALSE,NULL,$salto);
    }
    else
    {
		$_POST['tipotransporte']=str_replace("'", "''", $_POST['tipotransporte']);
		# exibindo mensagem de orientação
		printf("Incluindo o Registro...<br>\n");
		$tentativa=TRUE;
		while ( $tentativa )
		{ # 1.2.1-Laço de repetição para tratar a transação -----------------------------------------------------------------------------------------
		  $query = pg_query($link,"START TRANSACTION");
		  $proxpk=pg_fetch_array(pg_query($link,"SELECT max(idtransporte)+1 as CMAX FROM transporte"));
		  # A tabela pode estar vazia, neste caso o CMAX é nulo e $proxpk NÃO recebe valor. Então a proxima PK deve ser 1.
		  $cp=( isset($proxpk['CMAX']) ) ? $proxpk['CMAX'] : 1;
		  # Montando o comando de INSERT (Dentro do laço de repatição das tentativas porque o valor da PK depende da leitura da tabela 'dentro' da transação)
		  $cmd="INSERT INTO transporte VALUES ('$cp',
											'$_POST[tipotransporte]',
											'$_POST[cavalo]',
											'$_POST[quantidade]',
											'$_POST[placa]',										
											'$_POST[marca]',
											'$_POST[classificacao]',
											'$_POST[emplacado]',
											'$_POST[renavam]',
											'$_POST[chassi]',
											'$_POST[anomodelo]',
											'$_POST[qntdeixo]',
											'$_POST[largura]',
											'$_POST[altura]',
											'$_POST[comprimento]',
											'$_POST[pesomax]',
											'$_POST[nomeprop]',
											'$_POST[cpf]',
											'$_POST[telefone]',
											'$_POST[numcnh]',
											'$_POST[categoriahab]',
											'$_POST[validadecnh]',
											'$_POST[antt]',
											'$_POST[tipocarroceria]')";
								
		  $comando=pg_query($link,$cmd);
		  
		  switch (TRUE)
		  { # 1.2.1.1 - Avaliação da situação de erro (se existir).
			case pg_last_error($link) == 0 :
			{ 
			  $query=pg_query($link,"COMMIT");
			  printf("Registro <b>Inserido</b> com sucesso!<br>\n");
			  $tentativa=FALSE;
			  $mostra=TRUE;
			  break;
			} # 1.2.1.1.1 -------------------------------------------------------------------------------------------------------------------------
			case pg_last_error($link) == 1213 :
			{ # 1.2.1.1.2 - Erro de DeadLock - Cancelar e Reiniciar a transacao -----------------------------------------------------------------------
			  $query=pg_query($link,"ROLLBACK");
			  $tentativa=TRUE;
			  break;
			} # 1.2.1.1.2 -------------------------------------------------------------------------------------------------------------------------
			case pg_last_error($link) != 0 AND  pg_last_error($link)!= 1213 :
			{ # 1.2.1.1.3 - Erro! NÃO por deadlock. AVISAR o usuario. CANCELAR A transacao --------------------------------------------------------
			  printf("<b>Erro na tentativa de Inserir!</b><br>\n");
			  $mens=pg_last_error($link)." : ".pg_result_error($link);
			  printf("Mensagem: $mens<br>\n");
			  $query=pg_query($link,"ROLLBACK");
			  $tentativa=FALSE;
			  $mostra=FALSE;
			  break;
			} # 1.2.1.1.3 -------------------------------------------------------------------------------------------------------------------------
		  } # 1.2.1.1 - Fim do SWITCH tratando os status da transação -----------------------------------------------------------------------------
		} # 1.2.1 - Fim do Laço de repetição para tratar a transação ----------------------------------------------------------------------------
		if ( $mostra )
		{ # Executando a função do subprograma com o valor de $CP como PK. --------------------------------------------------------------------------
		  mostraregistro("$cp");
		} 
		botoes(FALSE,TRUE,TRUE,FALSE,NULL,$salto); # função do setfuncoes.php
		printf("<br>\n");
	}
		break;
  }
   # 1.2-Fim do Bloco de Tratamento da Transação -------------------------------------------------------------------------------------------
}
fimdepagina($acao,"transincluir.php",FALSE);
?>