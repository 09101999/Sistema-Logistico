<?php

function iniciapagina($tabela,$acao,$cordefundo)
{
  printf("<html>\n");
  printf("<head>\n<title>$acao</title>\n<meta http-equiv='content-type'>\n<meta content='text/html;'>\n<meta charset='utf-8'>\n</head>\n");
  printf("<body bgcolor='$cordefundo'>\n");
  printf("<center>\n<table border=0>\n<tr>\n<td><font color='red'><strong>$tabela</strong></font> - $acao<br><br>\n");}
function fimdepagina($acao,$prg,$center)
{
  printf("%s",($center) ? "<center>\n" : "" ); # Este comando combina um operador ternário DENTRO print().
  printf("<font size=2 color='gray'>$acao - Resolu&ccedil;&atilde;o m&iacute;nima de 1280x720 &copy; Copyright %s, FATEC Ourinhos - 6c&ordm;ADS - $prg</font>\n",date('Y'));
  printf("%s",($center) ? "</center>\n" : "" ); # Este comando combina um operador ternário DENTRO print().
  printf("</td>\n</tr>\n</table>\n</center>\n</body>\n</html>\n");
}
function botoes($pagina,$menu,$sair,$reset,$acao,$salto)
{ 
  $barra="";
  $barra=($sair)   ? $barra."<input class='button' type='button' value='< Sa&iacute;da' onclick='history.go(-($salto+1))'>" : $barra;
  $barra=($menu)   ? $barra."<input class='button' type='button' value='< Abertura' onclick='history.go(-$salto)'>" : $barra;
  $barra=($pagina) ? $barra."<input class='button' type='button' value='< 1 Pag.' onclick='history.go(-1)'>" : $barra;
  $barra=($reset)  ? $barra."<input class='button' type='reset'  value='Limpar'>" : $barra;
  $barra=( ISSET($acao) ) ? $barra."<input class='button' type='submit' value='$acao'>" : $barra;
  printf("$barra<br>\n");
}/*
function conectamy($host,$user,$senha,$dbname)
{ 
  header('content-type: text/html; charset=utf-8;');
  
  global $link;
  $link = mysqli_connect($host,$user,$senha,$dbname) or die ("A conex&atilde;o com o BD n&atilde;o deu certo");
  
  mysqli_query($link,"SET NAMES 'utf8'");
  mysqli_query($link,"SET character_set_connection=utf8");
  mysqli_query($link,"SET character_set_client=utf8");
  mysqli_query($link,"SET character_set_results=utf8");
}

conectamy("localhost","postgres","123456","logistica");
*/
function conecta_pg($host,$porta,$dbname,$user,$senha)
{ 
  $conexao = "host='".$host."' port=".$porta." dbname='".$dbname."' user='".$user."' password='".$senha."'";
 
  global $link;
  # Fazendo a conexão com o banco de dados.
  $link = pg_connect($conexao) or die ("Problemas para Conectar no Banco de Dados PostgreSQL: <br>$conexao");
  #printf("host=$host, port=$porta, dbname=$dbname,user=$user,password=$senha");
  # Agora vamos 'ajustar' os caracteres acentuados
  pg_query($link,"SET NAMES 'utf8'");
  pg_query($link,"SET CLIENT_ENCODING TO 'utf8'");
  pg_set_client_encoding('utf8'); # para a conexão com o PostgreSQL
}
conecta_pg("localhost",5433,"logistica","postgres","123456");

?>