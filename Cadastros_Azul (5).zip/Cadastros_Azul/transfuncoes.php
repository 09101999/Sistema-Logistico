<?php
# Aluna: Giovana Franklin Pereira de Castro (4ºADS-Vespertino) RA- 0210481712018;
#-------------------------------------------------------------------------------------------------------------------
function picklist($acao,$salto)
{
  global $link;
  # O Pickilist é 'chamado' em três programas... portanto deve retornar o form para três diferentes programas
  # que são determinados na variável $prg, usando operadores ternários.
  $prg=($acao=="Consultar") ? "transconsultar.php" : ( ($acao=="Alterar") ? "transalterar.php" : "transexcluir.php" );  
  # Lendo os dados de uma tabela por um comando de projeção
  $cmdsql="SELECT idtransporte, tipotransporte FROM transporte ORDER BY tipotransporte";
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  printf("$cmdsql\n");
  # construindo o form recursivo que apresenta a picklist
  printf("<form action='./$prg' method='POST'>\n");
  printf("<input type='hidden' name='salto' value=$salto>\n");
  printf("<input type='hidden' name='acao'  value=$acao>\n");
  printf("<input type='hidden' name='bloco' value=2>\n");
  $execcmd=pg_query($link,$cmdsql);
  printf("<select name='idtransporte'>\n");
  while ( $REG=pg_fetch_array($execcmd) )
  {
    printf("<option value='$REG[idtransporte]'>$REG[tipotransporte]-($REG[idtransporte])</option>\n");
  }
  printf("</select>\n");
  botoes(FALSE,TRUE,TRUE,TRUE,"$acao",$salto);
  printf("</form>\n");
}
function mostraregistro($CP)
{
  global $link;
 
  $cmdsql="SELECT * FROM transporte
		              WHERE transporte.idtransporte='$CP'";
  # executando a variável.
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  # printf("$cmdsql\n");
  $execcmd=pg_query($link,$cmdsql);
  $REG=pg_fetch_array($execcmd);
  
  printf("<table border=1>\n");
  		printf("<tr><td>Código Transporte</td><td>$REG[idtransporte]</td></tr>\n");
		printf("<tr><td>Tipo de Transporte </td><td>$REG[tipotransporte]</td></tr>\n");
		printf("<tr><td>Cavalo </td><td>$REG[cavalo]</td></tr>\n");
		printf("<tr><td>Quantidade </td><td>$REG[quantidade]</td></tr>\n");
		printf("<tr><td>Placa</td><td>$REG[placa]</td></tr>\n");
		printf("<tr><td>Marca</td><td>$REG[marca]</td></tr>\n");
        printf("<tr><td>Classificação</td><td>$REG[classificacao]</td></tr>\n");
        printf("<tr><td>Emplacado </td><td>$REG[emplacado]</td></tr>\n");
		printf("<tr><td>Renavam </td><td>$REG[renavam]</td></tr>\n");
		printf("<tr><td>Chassi </td><td>$REG[chassi]</td></tr>\n");
		printf("<tr><td>Ano do Modelo </td><td>$REG[anomodelo]</td></tr>\n");
		printf("<tr><td>Largura </td><td>$REG[largura]</td></tr>\n");
		printf("<tr><td>Altura </td><td>$REG[altura]</td></tr>\n");
		printf("<tr><td>Comprimento </td><td>$REG[comprimento]</td></tr>\n");
		printf("<tr><td>Peso Máximo </td><td>$REG[pesomax]</td></tr>\n");
		printf("<tr><td>Nome Proprietário </td><td>$REG[nomeprop]</td></tr>\n");
		printf("<tr><td>CPF </td><td>$REG[cpf]</td></tr>\n");
		printf("<tr><td>Telefone </td><td>$REG[telefone]</td></tr>\n");
		printf("<tr><td>Número CNH </td><td>$REG[numcnh]</td></tr>\n");
		printf("<tr><td>Categoria CNH </td><td>$REG[categoriahab]</td></tr>\n");
		printf("<tr><td>Validade CNH </td><td>$REG[validadecnh]</td></tr>\n");
		printf("<tr><td>ANTT </td><td>$REG[antt]</td></tr>\n");
		printf("<tr><td>Tipo Carroceria </td><td>$REG[tipocarroceria]</td></tr>\n");
  printf("</table>\n");
}
function montaform($acao,$bloco,$salto)
{ 
  global $link;
  $PK=(isset($_POST['idtransporte'])) ? $_POST['idtransporte'] : "1" ; 
  # Criar um vetor com valores dos campos do registro lido na tabela.
  //$co= pg_query();
  #$bd = pg_query($link,"SELECT * FROM transporte WHERE idtransporte='$PK'");
  $reg=(isset($POST['idtransporte'])) ? "" : pg_fetch_array(pg_query($link,"SELECT * FROM transporte WHERE idtransporte='$PK'"));
  #$reg=pg_fetch_array(pg_query($link," SELECT * FROM transporte WHERE idtransporte='$PK'"));
  #$reg=pg_fetch_array($bd);
 
  $bloco=$bloco+1;
  $mens=(isset($reg['idtransporte'])) ? $reg['idtransporte']."- N&Atilde;O Ser&aacute; Alterado pelo sistema" : "Ser&aacute; gerado pelo sistema";
  $prg=( $acao=='Incluir' ) ? "./transincluir.php" : "./transalterar.php" ;
 
  printf("<form action='$prg'  method='POST'>\n");
  printf("<input type='hidden' name='acao'  value='$acao'>\n");
  printf("<input type='hidden' name='bloco' value='$bloco'>\n");
  printf("<input type='hidden' name='salto' value='$salto'>\n");
  printf("%s",(isset($reg['idtransporte'])) ? "<input type='hidden' name='idtransporte' value='".$reg['idtransporte']."'>\n" : "");
  # Agora se monta uma tabela com os campos para entrada de dados.
  printf("<table border=0>\n");
  printf("<tr><td>C&oacute;digo:</td><td>$mens</td></tr>\n");
  printf("<tr><td>Tipo Transporte:</td><td><input type='text' name='tipotransporte' value=\"$reg[tipotransporte]\" size=50 maxlength=200></td></tr>\n");
  printf("<tr><td>Cavalo:</td><td><input type='text' name='cavalo' value=\"$reg[cavalo]\" size=50 maxlength=200></td></tr>\n");
  printf("<tr><td>Quantidade:</td><td><input type='text' name='quantidade' value=\"$reg[quantidade]\" size=50 maxlength=30></td></tr>\n");
  printf("<tr><td>Placa:</td><td><input type='text' name='placa' value=\"$reg[placa]\" size=50 maxlength=50></td></tr>\n");
  printf("<tr><td>Marca:</td><td><input type='text' name='marca' value=\"$reg[marca]\" size=50 maxlength=100></td></tr>\n");
  #printf("</td></tr>\n"); 
  printf("<tr><td>Classificação:</td><td><input type='text' name='classificacao' value=\"$reg[classificacao]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Emplacado:</td><td><input type='text' name='emplacado' value=\"$reg[emplacado]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Renavam:</td><td><input type='text' name='renavam' value=\"$reg[renavam]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Chassi:</td><td><input type='text' name='chassi' value=\"$reg[chassi]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Ano do Modelo:</td><td><input type='text' name='anomodelo' value=\"$reg[anomodelo]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Quantidade Eixo:</td><td><input type='text' name='qntdeixo' value=\"$reg[qntdeixo]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Largura:</td><td><input type='text' name='largura' value=\"$reg[largura]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Altura:</td><td><input type='text' name='altura' value=\"$reg[altura]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Comprimento:</td><td><input type='text' name='comprimento' value=\"$reg[comprimento]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Peso Máximo:</td><td><input type='text' name='pesomax' value=\"$reg[pesomax]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Nome Proprietário:</td><td><input type='text' name='nomeprop' value=\"$reg[nomeprop]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>CPF:</td><td><input type='text' name='cpf' value=\"$reg[cpf]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Telefone:</td><td><input type='text' name='telefone' value=\"$reg[telefone]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Número CNH:</td><td><input type='text' name='numcnh' value=\"$reg[numcnh]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Categoria da Habilitação:</td><td><input type='text' name='categoriahab' value=\"$reg[categoriahab]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>Validade da CNH:</td><td><input type='text' name='validadecnh' value=\"$reg[validadecnh]\" size=50 maxlength=100></td></tr>\n");
  printf("<tr><td>ANTT:</td><td><input type='text' name='antt' value=\"$reg[antt]\" size=50 maxlength=20></td></tr>\n");
  printf("<tr><td>Tipo Carroceria:</td><td><input type='text' name='tipocarroceria' value=\"$reg[tipocarroceria]\" size=50 maxlength=100></td></tr>\n");
  # montando os botões do form com a função botoes e os parâmetros:
  # (Página,Menu,Saída,Reset,Ação,$salto) TRUE | FALSE para os 4 parâmetros esq-dir.
  printf("<tr><td colspan=2>");
  botoes(FALSE,TRUE,TRUE,TRUE,$acao,$salto); # função do setfuncoes.php
  printf("</td></tr>\n");
  printf("</table>\n");
  printf("</form>\n");
}
?>