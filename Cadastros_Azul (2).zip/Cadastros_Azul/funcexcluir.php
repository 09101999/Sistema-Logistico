<?php

# Carregar o setfuncoes (e executar as funções Gerais disponíveis no grupo de funções)
require_once("../setfuncoes.php");# Atribuindo o valor de $bloco e $salto.
# Carregar o arquivo com as funções locais da tabela editora
require_once("./funcfuncoes.php");

$acao = ( ISSET($_POST['acao'])  ) ? $_POST['acao'] : "Excluir";
$bloco= ( ISSET($_POST['bloco']) ) ? $_POST['bloco'] : '1';
$salto= ( ISSET($_POST['salto']  ) ? $_POST['salto']+1 : '1');   // $salto recebe $_POST['salto']+1 (se houver), senão 1
$corfundo=( $acao=='Listar' AND $bloco==3 ) ? "#FFFFFF" /* white */ : "#FFDEAD" /* navajowhite */ ;
$corfonte="#000000"; # black - Cor da Fonte que é usada nos textos das telas (exceto títulos)
# iniciando a página
iniciapagina("Funcionário",$acao,$corfundo);
# Divisor principal de execução do programa
switch (TRUE)
{
  case ( $bloco==1 ):
  { # Montar a picklist
    picklist($acao,$salto);
    break;
  }
  case ( $bloco==2 ):
  { 
    mostraregistro("$_REQUEST[idfunc]");
    printf("<form action='./funcexcluir.php'  method='POST'>\n");
    printf("<input type='hidden' name='acao'  value='$acao'>\n");
    printf("<input type='hidden' name='bloco' value=3>\n");
    printf("<input type='hidden' name='salto' value='$salto'>\n");
    printf("<input type='hidden' name='idfunc' value='$_POST[idfunc]'>\n");
	#printf("<input type='hidden' name='nomefantasia' value='$_POST[nomefantasia]'>\n");
    # montando os botões do form com a função botoes e os parâmetros:
    # (Página,Menu,Saída,Reset,Ação,$salto) TRUE | FALSE para os 4 parâmetros esq-dir.
    botoes(TRUE,TRUE,TRUE,FALSE,"Confirma a Exclus&atilde;o",$salto); # função do setfuncoes.php
    printf("</form>\n");
    break;
  } # 1.2 ---------------------------------------------------------------------------------------------------------------------------------------
  case ( $bloco==3 ):
  { # 1.3-Bloco para Tratamento da Transação
    # Montando o comando de DELETE
    $cmd="DELETE FROM funcionario WHERE idfunc='$_POST[idfunc]'";
    # printf("$cmd<br>\n");
    # exibindo mensagem de orientação
    printf("Excluindo o Registro...<br>\n");
    
    $tentativa=TRUE;
    while ( $tentativa )
    { # 1.3.1-Laço de repetição para tratar a transação -----------------------------------------------------------------------------------------
      $query = pg_query($link,"START TRANSACTION");
      
      $comando=pg_query($link,$cmd);
      # O Próximo SWITCH trata as situações de erro. A função mysqli_get_result($link) retorna o número do erro do MySQL.
      switch (TRUE)
      { # 1.3.1.1 - Avaliação da situação de erro (se existir). ---------------------------------------------------------------------------------
        case pg_errno($link) == 0 :
        { 
          $query=pg_query($link,"COMMIT"); # A captura do erro fica fora do SWITCH CASE
          printf("Registro <b>Exclu&iacute;do</b> com sucesso!<br>\n");
          $tentativa=FALSE;
          break;
        } # 1.3.1.1.1 ---------------------------------------------------------------------------------------------------------------------------
        case pg_errno($link) == 1213 :
        { # 1.3.1.1.2 - Erro de DeadLock - Cancelar e Reiniciar a transacao
          $query= pg_query($link,"ROLLBACK");
          $tentativa=TRUE;
          break;
        } # 1.3.1.1.2 ---------------------------------------------------------------------------------------------------------------------------
        case pg_errno($link) != 0 AND  pg_errno($link)!= 1213 :
        { # 1.3.1.1.3 - Erro! NÃO por deadlock. AVISAR o usuario. CANCELAR A transacao ----------------------------------------------------------
          printf("<b>Erro na tentativa de Excluir!</b><br>\n");
          $mens=pg_errno($link)." : ".pg_error($link);
          printf("Mensagem: $mens<br>\n");
          $query=pg_query($link,"ROLLBACK");
          $tentativa=FALSE;
          break;
        } # 1.3.1.1.3 ---------------------------------------------------------------------------------------------------------------------------
      } # 1.3.1.1 - Fim do SWITCH tratando os status da transação -------------------------------------------------------------------------------
    } # 1.3.1-Fim do Laço de repetição para tratar a transação ----------------------------------------------------------------------------------
   
    botoes(FALSE,TRUE,TRUE,FALSE,NULL,$salto);
    printf("<br>\n");
    break;
  } # 1.3-Fim do Bloco de Tratamento da Transação -----------------------------------------------------------------------------------------------
} # 1-Fim do divisor de blocos principal --------------------------------------------------------------------------------------------------------
fimdepagina($acao,"funcexcluir.php",FALSE);
?>