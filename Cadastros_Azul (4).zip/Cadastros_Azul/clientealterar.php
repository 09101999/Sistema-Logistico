<<?php

require_once("../setfuncoes.php");
# Carregar o arquivo com as funções locais da tabela editora
require_once("./clientefuncoes.php");
# Atribuindo o valor de $acao, $bloco, $salto, $corfundo e $corfonte
$acao = ( ISSET($_POST['acao'])  ) ? $_POST['acao'] : "Alterar";
$bloco= ( ISSET($_POST['bloco']) ) ? $bloco=$_POST['bloco'] : '1';
$salto= ( ISSET($_POST['salto']  ) ? $_POST['salto']+1 : '1');   // $salto recebe $_POST['salto']+1 (se houver), senão 1
$corfundo="#87CEEB"; # navajowhite "#D3D3D3"; # lightgray
$corfonte="#000000"; # black
# executar a função que inicia a página (define cor de fundo, cor de fonte, alinhamento e textos iniciais)
iniciapagina("Cores",$acao,$corfundo);
# Desvio de Blocos Principais baseado em $bloco.
SWITCH (TRUE)
{ # 1 - Este é o comando de desvio principal do programa. -----------------------------------------------------------------------------------
  case ( $bloco==1 ):
  { # 1.1 - executa a função picklist() - monta a picklist escolhendo o registro de alteração -----------------------------------------------
    picklist($acao,$salto);
    break;
  } # 1.1 -----------------------------------------------------------------------------------------------------------------------------------
  case ( $bloco==2 ):
  { # 1.2 - ---------------------------------------------------------------------------------------------------------------------------------
    montaform($acao,$bloco,$salto);
    break;
  } # 1.2-Fim do Bloco de exibir registro ---------------------------------------------------------------------------------------------------
  case ( $bloco==3 ):
  { 
    $_POST['nomefantasia']=str_replace("'", "''", $_POST['nomefantasia']);
    $_POST['razaosocial']=str_replace("'", "''", $_POST['razaosocial']);
    # Montando o comando de UPDATE
    # (Está quebrado em mais de uma linha mas isso não faz diferença para o MySQL, porém fica mais fácil de achar algum eventual erro)
    $cmd="UPDATE cliente SET 	razaosocial = '$_POST[razaosocial]',
								nomefantasia = '$_POST[nomefantasia]',
								cnpj       = '$_POST[cnpj]',
								endereco   = '$_POST[endereco]'
								bairro     = '$_POST[bairro]',
								cidade     = '$_POST[cidade]',
								estado     = '$_POST[estado]',
								cep        = '$_POST[cep]',
								email      = '$_POST[email]',
								telefone   = '$_POST[telefone]',
								inscricaoestadual = '$_POST[inscricaoestadual]',
								filial     = '$_POST[filial]',
                                tipoestabelecimento = '$_POST[tipoestabelecimento]',
                             WHERE idcliente='$_POST[idcliente]'";
    # Ajustando a tabela de simbolos recebidos/enviados para o BD para UTF8
    pg_query($link,"SET NAMES 'utf8'");
    pg_query($link,"SET CLIENT_ENCODING TO 'utf8'");
    # exibindo mensagem de orientação
    printf("Alterando o Registro...<br>\n");
    $tentativa=TRUE;
    while ( $tentativa )
    { # 1.3.1-Laço de repetição para tratar a transação -------------------------------------------------------------------------------------
      $query = pg_query($link,"START TRANSACTION");
      $comando=pg_query($link,$cmd);
      # O Próximo SWITCH trata as situações de erro. A função mysqli_get_result($link) retorna o número do erro do MySQL.
      switch (TRUE)
      { # 1.3.1.1 - Avaliação da situação de erro (se existir) --------------------------------------------------------------------------------
        case pg_last_error($link) == 0 :
        { 
          $query=pg_last_error($link,"COMMIT");
          printf("Registro <b>Alterado</b> com sucesso!<br>\n");
          $tentativa=FALSE;
          $mostra=TRUE;
          break;
        } # 1.3.1.1.1 -------------------------------------------------------------------------------------------------------------------------
        case pg_last_error($link) == 1213 :
        { # 1.3.1.1.2 - Erro de DeadLock - Cancelar e Reiniciar a transacao -------------------------------------------------------------------
          $query=pg_query($link,"ROLLBACK");
          $tentativa=TRUE;
          break;
        } # 1.3.1.1.2 -------------------------------------------------------------------------------------------------------------------------
        case pg_last_error($link) != 0 AND  pg_last_error($link)!= 1213 :
        { # 1.3.1.1.3 - Erro! NÃO por deadlock. AVISAR o usuario. CANCELAR A transacao --------------------------------------------------------
          printf("<b>Erro na tentativa de Inserir!</b><br>\n");
          $mens=pg_last_error($link)." : ".pg_result_error($link);
          printf("Mensagem: $mens<br>\n");
          $query=pg_query($link,"ROLLBACK");
          $tentativa=FALSE;
          $mostra=FALSE;
          break;
        } # 1.3.1.1.3 --------------------------------------------------------------------------------------------------------------------------
      } # 1.3.1.1 - Fim do SWITCH tratando os status da transação ------------------------------------------------------------------------------
    } # 1.3.1-Fim do Laço de repetição para tratar a transação -------------------------------------------------------------------------------
    if ( $mostra )
    { # Executando a função do subprograma com o valor de $CP como PK.
      mostraregistro("$_POST[idcliente]");
    } 
    botoes(FALSE,TRUE,TRUE,FALSE,NULL,$salto); # função do setfuncoes.php
    printf("<br>\n");
    break;
  } # 1.3-Fim do Bloco de Tratamento da Transação -------------------------------------------------------------------------------------------
} # 1-Fim do divisor de blocos principAl ----------------------------------------------------------------------------------------------------
fimdepagina($acao,"clienteincluir.php",FALSE);
?>