<?php
# Aluna: Giovana Franklin Pereira de Castro (4ºADS-Vespertino) RA- 0210481712018;
#-------------------------------------------------------------------------------------------------------------------
function picklist($acao,$salto)
{
  global $link;
  # O Pickilist é 'chamado' em três programas... portanto deve retornar o form para três diferentes programas
  # que são determinados na variável $prg, usando operadores ternários.
  $prg=($acao=="Consultar") ? "funcconsultar.php" : ( ($acao=="Alterar") ? "funcalterar.php" : "funcexcluir.php" );  
  # Lendo os dados de uma tabela por um comando de projeção
  $cmdsql="SELECT idfunc, nome FROM funcionario ORDER BY idfunc";
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  printf("$cmdsql\n");
  # construindo o form recursivo que apresenta a picklist
  printf("<form action='./$prg' method='POST'>\n");
  printf("<input type='hidden' name='salto' value=$salto>\n");
  printf("<input type='hidden' name='acao'  value=$acao>\n");
  printf("<input type='hidden' name='bloco' value=2>\n");
  $execcmd=pg_query($link,$cmdsql);
  printf("<select name='idfunc'>\n");
  while ( $REG=pg_fetch_array($execcmd) )
  {
    printf("<option value='$REG[idfunc]'>$REG[nome]-($REG[idfunc])</option>\n");
  }
  printf("</select>\n");
  botoes(FALSE,TRUE,TRUE,TRUE,"$acao",$salto);
  printf("</form>\n");
}
function mostraregistro($CP)
{
  global $link;
 
  $cmdsql="SELECT * FROM funcionario
		              WHERE funcionario.idfunc='$CP'";
  # executando a variável.
  # Caso aconteça alguma coisa errada na conexão... tire o comentário e veja o comando que foi executado no servidor
  # printf("$cmdsql\n");
  $execcmd=pg_query($link,$cmdsql);
  $REG=pg_fetch_array($execcmd);
  printf("<table border=1>\n");
  		printf("<tr><td>Código Funcionário</td><td>$REG[idfunc]</td></tr>\n");
		printf("<tr><td>Nome </td><td>$REG[nome]</td></tr>\n");
		printf("<tr><td>Endereço</td><td>$REG[endereco]</td></tr>\n");
		printf("<tr><td>Email</td><td>$REG[email]</td></tr>\n");
		printf("<tr><td>Telefone</td><td>$REG[telefone]</td></tr>\n");
		printf("<tr><td>CPF</td><td>$REG[cpf]</td></tr>\n");
		printf("<tr><td>RG</td><td>$REG[rg]</td></tr>\n");
		printf("<tr><td>Função</td><td>$REG[funcao]</td></tr>\n");
		//printf("<tr><td>Endereço</td><td>$REG[endereco]</td></tr>\n");
		//printf("<tr><td>Estado</td><td>$REG[estado]</td></tr>\n");
        //printf("<tr><td>Bairro</td><td>$REG[bairro]</td></tr>\n");
        //printf("<tr><td>Cidade</td><td>$REG[cidade]</td></tr>\n");
		//printf("<tr><td>CEP</td><td>$REG[cep]</td></tr>\n");
  
  printf("</table>\n");
}
function montaform($acao,$bloco,$salto)
{ 
  global $link;
  $PK=(isset($_POST['idfunc'])) ? $_POST['idfunc'] : "" ;
  # Criar um vetor com valores dos campos do registro lido na tabela.
  $bd=pg_query($link,"SELECT * FROM funcionario  WHERE idfunc='$PK'");
  $reg=pg_fetch_array($bd);
 
  $bloco=$bloco+1;
  $mens=(isset($reg['idfunc'])) ? $reg['idfunc']." - N&Atilde;O Ser&aacute; Alterado pelo sistema" : "Ser&aacute; gerado pelo sistema";
  $prg=( $acao=='Incluir' ) ? "./funcincluir.php" : "./funcalterar.php" ;
 
  printf("<form action='$prg'  method='POST'>\n");
  printf("<input type='hidden' name='acao'  value='$acao'>\n");
  printf("<input type='hidden' name='bloco' value='$bloco'>\n");
  printf("<input type='hidden' name='salto' value='$salto'>\n");
  printf("%s",(isset($reg['idfunc'])) ? "<input type='hidden' name='idfunc' value='".$reg['idfunc']."'>\n" : "");
  # Agora se monta uma tabela com os campos para entrada de dados.
  printf("<table border=0>\n");
  printf("<tr><td>C&oacute;digo:</td><td>$mens</td></tr>\n");
  printf("<tr><td>Nome</td><td><input type='text' name='nome' value=\"$reg[nome]\" size=60 maxlength=250></td></tr>\n");
  printf("<tr><td>Telefone:</td><td><input type='text' name='telefone' value=\"$reg[telefone]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Endereço:</td><td><input type='text' name='endereco' value=\"$reg[endereco]\" size=20 maxlength=15></td></tr>\n");
  printf("<tr><td>Email:</td><td><input type='text' name='email' value=\"$reg[email]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>CPF: </td><td><input type='text' name='cpf' value=\"$reg[cpf]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>RG:</td><td><input type='text' name='rg' value=\"$reg[rg]\" size=20 maxlength=20></td></tr>\n");
  printf("<tr><td>Função:</td><td><input type='text' name='funcao' value=\"$reg[funcao]\" size=20 maxlength=20></td></tr>\n");
  
  #printf("</td></tr>\n");
  
  //printf("<tr><td>Bairro:</td><td><input type='text' name='bairro' value=\"$reg[bairro]\" size=20 maxlength=20></td></tr>\n");
 // printf("<tr><td>Cidade:</td><td><input type='text' name='cidade' value=\"$reg[cidade]\" size=20 maxlength=20></td></tr>\n");
  //printf("<tr><td>Estado:</td><td><input type='text' name='estado' value=\"$reg[estado]\" size=20 maxlength=20></td></tr>\n");
 // printf("<tr><td>CEP:</td><td><input type='text' name='cep' value=\"$reg[cep]\" size=20 maxlength=20></td></tr>\n");

  # montando os botões do form com a função botoes e os parâmetros:
  # (Página,Menu,Saída,Reset,Ação,$salto) TRUE | FALSE para os 4 parâmetros esq-dir.
  printf("<tr><td colspan=2>");
  botoes(FALSE,TRUE,TRUE,TRUE,$acao,$salto); # função do setfuncoes.php
  printf("</td></tr>\n");
  printf("</table>\n");
  printf("</form>\n");
}
?>