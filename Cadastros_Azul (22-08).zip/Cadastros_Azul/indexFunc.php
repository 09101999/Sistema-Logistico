<?php

printf("<html>\n");
printf("<head>\n");
printf(" <meta charset='utf-8'>\n");
printf("<title>Transit</title>\n");
printf("</head>\n");
printf("<frameset rows='50,*' frameborder='no'>\n");
printf("  <frame name='Q1' src='menuFunc.html' scrolling='no'>\n");
printf("  <frame name='Q2' src='CadFuncionario_Azul.html'>\n");
printf("</frameset>\n");
printf("</html>\n");
?>