<?php
//include('conexao.php');

function conecta_pg($host,$porta,$dbname,$user,$senha)
{ # Função.....: conecta_pg
  $conexao = "host='".$host."' port=".$porta." dbname='".$dbname."' user='".$user."' password='".$senha."'";
  # Conectando o PostgreSQL. O Ponteiro que retorna na conexão DEVE SER armazenado em uma variavel GLOBAL.
  global $link;
  # Fazendo a conexão com o banco de dados.
  $link = pg_connect($conexao) or die ("Problemas para Conectar no Banco de Dados PostgreSQL: <br>$conexao");
  # Agora vamos 'ajustar' os caracteres acentuados
  pg_query($link,"SET NAMES 'utf8'");
  pg_query($link,"SET CLIENT_ENCODING TO 'utf8'");
  pg_set_client_encoding('utf8'); # para a conexão com o PostgreSQL
  # Fim da função conecta_pg
}

conecta_pg("localhost","5433","logistica","postgres","123456");

mysql_select_db('funcionario', conecta_pg);

	if(mysqli_connect_errno(conecta_pg))
	{
		echo "problema ao conectar";
	}
		else{
			"Conexao feita";
		}

$login = $_POST["email"];
$senha = $_POST["pass"];

$selecao = mysql_query("SELECT email, senha from funcionario where email = '$login' and senha = '$senha'");

$result = mysqli_query(conecta_pg, $selecao);
$row = mysqli_num_rows($result);

	if($row == 1)
	{
		echo "BEM VINDO(A) <br> $login </br>";
		
		exit();
	}else {
		header('Location: login.php');
		exit();
	}
?>
/*
if(empty($_POST['email']) || empty($_POST['senha'])){
	header('Location: login.html');
	exit();
}
$email = mysqli_real_escape_string(conecta_pg, $_POST['email']);
$senha = mysqli_real_escape_string(conecta_pg, $_POST['senha']);

$query = "select idfunc, email, senha from funcionario where email = '{$email}' and senha = '{$senha}'";

$result = mysqli_query(conecta_pg, $query);
$row = mysqli_num_rows($result);

if($row == 1) {
	$_SESSION['usuario'] = $usuario;
	exit();
} else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: login.php');
	exit();
}*/

