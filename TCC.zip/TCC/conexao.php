<?php
#define ('HOST', 'localhost');
#define ('PORTA', '5433');
#define ('USER', 'postgres');
#define ('SENHA', '123456');
#define ('DB', 'logistica');

#$conexao = mysql_connect('localhost', '5433', 'postgres', '123456', 'logistica') or die ('Não foi possivel conectar ao banco de dados!');

function conecta_pg($host,$porta,$dbname,$user,$senha)
{ # Função.....: conecta_pg
  $conexao = "host='".$host."' port=".$porta." dbname='".$dbname."' user='".$user."' password='".$senha."'";
  # Conectando o PostgreSQL. O Ponteiro que retorna na conexão DEVE SER armazenado em uma variavel GLOBAL.
  global $link;
  # Fazendo a conexão com o banco de dados.
  $link = pg_connect($conexao) or die ("Problemas para Conectar no Banco de Dados PostgreSQL: <br>$conexao");
  # Agora vamos 'ajustar' os caracteres acentuados
  pg_query($link,"SET NAMES 'utf8'");
  pg_query($link,"SET CLIENT_ENCODING TO 'utf8'");
  pg_set_client_encoding('utf8'); # para a conexão com o PostgreSQL
  # Fim da função conecta_pg
}

conecta_pg("localhost",5433,"lbdpg2","postgres","123456");

?>
  